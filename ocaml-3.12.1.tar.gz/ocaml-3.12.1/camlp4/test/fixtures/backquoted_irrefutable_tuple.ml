EXTEND Gram
  abc: [ [ `(x,y) -> x + y ] ];
END;
