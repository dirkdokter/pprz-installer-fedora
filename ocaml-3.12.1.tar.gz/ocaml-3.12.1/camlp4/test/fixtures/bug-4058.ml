let _ = (fun x -> x), 1
let _ = (x := 1), 2
let _ = (x <- 1), 2
let _ = (if true then 1 else 2), 1
