match [] with []°-> () | _ -> ();;
