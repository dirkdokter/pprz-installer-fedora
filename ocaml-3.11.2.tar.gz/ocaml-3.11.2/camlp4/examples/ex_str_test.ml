function <<foo>> -> <<bar>>
